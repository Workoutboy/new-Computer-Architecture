import tkinter as tk
from tkinter import messagebox
import random

cell_size=30
C=12
R=20
height=R*cell_size
width=C*cell_size

FPS=500 #刷新頁面的毫秒間隔

#透過中心點來繪製各個俄羅斯方塊的小方塊位置
SHAPES={
    "O":[(-1,-1),(0,-1),(-1,0),(0,0)],
    "Z":[(-1,-1),(0,-1),(1,0),(0,0)],
    "S":[(1,-1),(0,-1),(-1,0),(0,0)],
    "T":[(-1,0),(0,-1),(1,0),(0,0)],
    "I":[(0,-1),(0,1),(0,-2),(0,0)],
    "L":[(-1,-2),(-1,-1),(-1,0),(0,0)],
    "J":[(-1,0),(0,-1),(0,-2),(0,0)],
    "P":[(-1,-1),(0,-1),(-1,0),(0,0),(0,-2)],
    "Q":[(-1,-1),(0,-1),(-1,0),(0,0),(-1,-2)],
}
#選定O型方塊的顏色(O型方塊代表色為黃色)
SHAPESCOLOR={
    "O":"yellow",
    "Z":"green",
    "S":"red",
    "T":"purple",
    "I":"Cyan",
    "L":"orange",
    "J":"blue",
    "P":"black",
    "Q":"gold",
}
def draw_cell_by_cr(canvas,c,r,color="#CCCCCC",tag_kind=""): #在畫板上繪制單個俄邏斯方塊
    """
    :param canvas: 面板,用於繪制一個方塊的canvas對象
    :param c: 方塊所在列
    :param r: 方塊所在行
    :param color: 方塊顏色,默認為#CCCCCC,輕灰色
    :return:
    """
    x0=c*cell_size
    y0=r*cell_size
    x1=c*cell_size + cell_size
    y1=r*cell_size + cell_size
    if tag_kind == "falling":
        canvas.create_rectangle(x0, y0, x1, y1, fill=color,outline="white", width=2, tag=tag_kind)
    elif tag_kind == "row":
        canvas.create_rectangle(x0, y0, x1, y1, fill=color, outline="white", width=2, tag="row-%s" % r)
    else:
        canvas.create_rectangle(x0, y0, x1, y1, fill=color, outline="white", width=2)

def draw_board(canvas, block_list, isFirst=False): #繪制面板上殘留的俄邏斯方塊

    for ri in range(R):
        canvas.delete("row-%s" % ri)

    for ri in range(R):
        for ci in range(C):
            cell_type = block_list[ri][ci]
            if cell_type:
                draw_cell_by_cr(canvas, ci, ri, SHAPESCOLOR[cell_type], tag_kind="row")
            elif isFirst:
                draw_cell_by_cr(canvas, ci, ri)

def draw_cells(canvas,c,r,cell_list,color="#CCCCCC"): #繪制指定形狀指定顏色的俄邏斯方塊
    """
    :param canvas: 畫板
    :param c: 該形狀設定的原點所在的列
    :param r: 該形狀設定的原點所在的行
    :param cell_list: 該形狀各個方格相對自身所處位置
    :param color: 該形狀顏色
    :return:
    """
    for cell in cell_list:
        cell_c,cell_r = cell
        ci=cell_c + c
        ri = cell_r + r
        #判斷方格位置在畫板內部(畫板外部的方格不再繪制)
        if 0 <= c < C and 0 <= r<R:
            draw_cell_by_cr(canvas,ci,ri,color,tag_kind="falling")

win = tk.Tk()
canvas=tk.Canvas(win,width=width,height=height)
canvas.pack()

block_list = []
for i in range(R):
    i_row = ['' for j in range(C)]
    block_list.append(i_row)

draw_board(canvas, block_list,True)

def draw_block_move(canvas,block,direction=[0,0]): #繪制俄邏斯方塊的移動
    """
    :param canvas: 畫板
    :param block: 俄邏斯方塊對象
    :param direction: 俄邏斯方塊移動方向
    :return:
    """
    shape_type = block['kind']
    c,r = block['cr']
    cell_list = block['cell_list']

    canvas.delete("falling")

    dc, dr = direction
    new_c, new_r = c + dc, r + dr
    block['cr'] = [new_c, new_r]

    draw_cells(canvas, new_c, new_r, cell_list, SHAPESCOLOR[shape_type])

def generate_new_block(): #隨機生成俄邏斯方塊
    # 隨機生成新的俄邏斯方塊

    kind = random.choice(list(SHAPES.keys()))
    # 對應橫縱坐標,以左上角為原點,水平向右為x軸正方向
    # 竪直向下為y軸正方向,x對應橫坐標,y對應縱坐標
    cr = [C // 2,0]
    new_block={
        'kind':kind, #對應俄邏斯方塊的類型
        'cell_list':SHAPES[kind],
        'cr':cr
    }
    return new_block

def check_move(block,direction=[0,0]): #判斷俄邏斯方塊是否可以朝制定方向移動
    """
        :param block: 俄邏斯方塊對象
        :param direction: 俄邏斯方塊移動方向
        :return boolean:是否可以朝制定方向移動
        """
    cc, cr = block['cr']
    cell_list = block['cell_list']

    for cell in cell_list:
        cell_c,cell_r = cell
        c = cell_c + cc + direction[0]
        r = cell_r + cr + direction[1]
        #判斷該位置是否超出左右邊界及下邊界,不判斷上邊界，因為俄邏斯方塊生成的時候，可能有一部分在上邊界之上還沒有出來
        if c < 0 or c >= C or r >= R:
            return False

        #必須要判斷r不小於0才行，具體原因可以不加這個判斷，試試會出現什麼效果
        if r >= 0 and block_list[r][c]:
            return False

    return True

def check_row_complete(row): #判斷指定行是否可以消除
        for cell in row:
            if cell == '':
                return False

        return True

score = 0
win.title("SCORES: %s" % score) #標題中展示分數

def check_and_clear(): #檢查所有行並消除
    has_complete_row = False
    for ri in range(len(block_list)):
        if check_row_complete(block_list[ri]):
            has_complete_row = True
            #當前行可以消除
            if ri > 0:
                for cur_ri in range(ri, 0, -1):
                    block_list[cur_ri] = block_list[cur_ri-1][:]
                block_list[0] = ['' for j in range(C)]
            else:
                block_list[ri] = ['' for j in range(C)]
            global score
            score += 10

    if has_complete_row:
        draw_board(canvas, block_list)

        win.title("SCORES: %s" % score)

def save_block_to_list(block):  # 將無法移動的俄邏斯方塊記錄進去

        canvas.delete("falling")

        shape_type = block['kind']
        cc, cr = block['cr']
        cell_list = block['cell_list']

        for cell in cell_list:
            cell_c, cell_r = cell
            c = cell_c + cc
            r = cell_r + cr
            # block_list 在對應位置下記下其類型
            block_list[r][c] = shape_type

            draw_cell_by_cr(canvas, c, r, SHAPESCOLOR[shape_type], tag_kind="row")
def horizontal_move_block(event):  # 左右移動俄邏斯方塊
        direction = [0, 0]
        if event.keysym == 'Left':
            direction = [-1, 0]
        elif event.keysym == 'Right':
            direction = [1, 0]
        else:
            return

        global current_block
        if current_block is not None and check_move(current_block, direction):
            draw_block_move(canvas, current_block, direction)

def rotate_block(event):  # 旋轉俄邏斯方塊
    global current_block
    if current_block is None:
        return

    cell_list = current_block['cell_list']
    rotate_list = []
    for cell in cell_list:
        cell_c, cell_r = cell
        rotate_cell = [cell_r, -cell_c]
        rotate_list.append(rotate_cell)

    block_after_rotate = {
        'kind': current_block['kind'],  # 對應俄邏斯方塊的類型
        'cell_list': rotate_list,
        'cr': current_block['cr']
        }

    if check_move(block_after_rotate):
        cc, cr = current_block['cr']
        draw_cells(canvas, cc, cr, current_block['cell_list'])
        draw_cells(canvas, cc, cr, rotate_list, SHAPESCOLOR[current_block['kind']])
        current_block = block_after_rotate

def land(event):  # 讓俄邏斯方塊著陸
    global current_block
    if current_block is None:
        return

    cell_list = current_block['cell_list']
    cc,cr = current_block['cr']
    min_height = R
    for cell in cell_list:
        cell_c, cell_r = cell
        c,r = cell_c + cc, cell_r + cr
        if r>=0 and block_list[r][c]:
            return
        h = 0
        for ri in range(r+1,R):
            if block_list[ri][c]:
                break
            else:
                h += 1
        if h < min_height:
            min_height = h

    down = [0,min_height]
    if check_move(current_block,down):
        draw_block_move(canvas, current_block,down)

def game_loop(): #遊戲運行
    win.update()
    global current_block
    if current_block is None:
        new_block = generate_new_block()
        #新生成的俄邏斯方塊需要先在生成位置繪制出來
        draw_block_move(canvas, new_block)
        current_block = new_block
        if not check_move(current_block, [0, 0]):
            messagebox.showinfo("Game Over!", "Your Score is %s" % score)
            win.destroy()
            return
    else:
        if check_move(current_block, [0, 1]):
            draw_block_move(canvas, current_block, [0, 1])
        else:
            # 無法移動，記入 block_list 中
            save_block_to_list(current_block)
            current_block = None
            check_and_clear()

    win.after(FPS, game_loop)
#把鍵盤上的左右鍵綁定
canvas.focus_set()#聚焦到canvas畫板對象上
canvas.bind("<KeyPress-Left>",horizontal_move_block)
canvas.bind("<KeyPress-Right>",horizontal_move_block)
#把鍵盤上的x鍵綁定
canvas.bind("<KeyPress-x>",rotate_block)
#把鍵盤上的空白鍵綁定
canvas.bind("<KeyPress-space>",land)

current_block=None

win.update()
win.after(FPS,game_loop) #在FPS毫秒後用game_loop方法

win.mainloop()
